var name = (Nombre="Agustina");
console.log(name);

var edad = 22 ;
console.log(edad); 

var ignasiAge = 32;
var agedif= ignasiAge-edad;
console.log(agedif);

if (edad<21) {
    console.log("No tiene más de 21 años");
} 

else (edad>21) 
    console.log("Tiene más de 21 años");

if (edad<ignasiAge) {
    console.log("Ignasi es mayor que usted")
}
else if (edad==ignasiAge){
    console.log("Tiene la misma edad que Ignasi ")
}
else
    console.log(" Ignasi es más joven que usted")



